﻿namespace CHUSHKA.Data
{
    public class DbSet<T>
    {
    }
}