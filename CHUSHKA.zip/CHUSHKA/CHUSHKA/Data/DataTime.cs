﻿namespace CHUSHKA.Data
{
    public class DataTime
    {
    }
}