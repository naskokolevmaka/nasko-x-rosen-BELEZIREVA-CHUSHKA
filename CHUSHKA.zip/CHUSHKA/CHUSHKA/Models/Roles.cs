﻿namespace CHUSHKA.Models
{
    internal class Roles
    {
    }
}