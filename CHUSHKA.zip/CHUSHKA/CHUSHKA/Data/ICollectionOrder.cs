﻿namespace CHUSHKA.Data
{
    internal interface ICollectionOrder
    {
    }
}