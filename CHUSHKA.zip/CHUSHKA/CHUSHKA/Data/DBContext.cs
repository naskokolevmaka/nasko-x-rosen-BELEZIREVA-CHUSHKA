﻿namespace CHUSHKA.Data
{
    public class DBContext
    {
        private DbContextOptions<ProductOrderContects> option;

        public DBContext(DbContextOptions<ProductOrderContects> option)
        {
            this.option = option;
        }
    }
}