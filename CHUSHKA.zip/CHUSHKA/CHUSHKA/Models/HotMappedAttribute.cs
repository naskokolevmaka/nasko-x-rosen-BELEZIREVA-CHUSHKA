﻿using System;

namespace CHUSHKA.Models
{
    internal class HotMappedAttribute : Attribute
    {
    }
}