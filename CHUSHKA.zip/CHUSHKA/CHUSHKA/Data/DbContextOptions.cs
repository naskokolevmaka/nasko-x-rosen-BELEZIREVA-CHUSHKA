﻿namespace CHUSHKA.Data
{
    public class DbContextOptions<T>
    {
    }
}